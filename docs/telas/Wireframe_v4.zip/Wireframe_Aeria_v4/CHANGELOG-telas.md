# Aeria Drones · protótipo de telas v4

Base: `Wireframe_Cadastro_Produto_Drone_v2`, com as decisões D17 e D18 já aplicadas. Motivo da revisão: fechar as lacunas
entre os 8 diagramas de classe e as telas do painel administrativo, para que todo
CRUD do Lote 1 e do Lote 2 tenha listagem (read/update/delete) e formulário (create).

Total de telas: **36** (16 storefront + 20 admin). Antes eram 22.

## Convenção adotada

O plural é a **listagem**, o singular é o **formulário**. Já era o padrão de
`produtos.html` + `produto-novo.html` e `pedidos.html` + `pedido.html`; agora vale
para todo o painel.

## Telas novas (12)

| Arquivo | Tipo | Entidade |
|---|---|---|
| `site/admin/fornecedores.html` | listagem | Fornecedor |
| `site/admin/fornecedor-novo.html` | formulário | Fornecedor |
| `site/admin/promocoes.html` | listagem | Promocao |
| `site/admin/promocao-nova.html` | formulário | Promocao |
| `site/admin/cupons.html` | listagem | Cupom |
| `site/admin/cupom-novo.html` | formulário | Cupom |
| `site/admin/estoque.html` | listagem | VarianteProduto (saldo) |
| `site/admin/estoque-movimento.html` | formulário | MovimentoEstoque |
| `site/admin/acessorio-novo.html` | formulário | Acessorio |
| `site/admin/marca-nova.html` | formulário | Marca (movido) |
| `site/admin/categoria-nova.html` | formulário | Categoria (movido) |
| `site/admin/usuario-novo.html` | formulário | Usuario + PerfilAdministrativo (movido) |

## Telas que mudaram de papel (3)

`marcas.html`, `categorias.html` e `usuarios.html` eram formulários de cadastro.
Viraram listagens. O conteúdo original dos formulários foi preservado sem perda nos
arquivos `marca-nova.html`, `categoria-nova.html` e `usuario-novo.html`.

## Correções e ajustes

- Navegação do admin reescrita nas 20 telas: 10 seções, com o item ativo marcado corretamente.
- `site/assets/site.css`: `.tb-nav` ganhou `flex-wrap` e `.tb` virou `min-height`, para a barra comportar 10 itens sem estourar.
- `produtos.html`: botão "Novo acessório" e filtro "Tipo" (drone / acessório).
- `produto-novo.html`: o link "Promoções" apontava para `produtos.html`, agora vai para `promocoes.html`; o select de fornecedor ganhou opções.
- `admin/index.html`: o card "Estoque baixo" agora leva para `estoque.html`.
- `conta-perfil.html`: link para `perfil.html`, que não existe, corrigido para `conta-enderecos.html`.
- `diagramas/`: substituídos os dois `.puml` desatualizados da raiz pelos 8 arquivos atuais por contexto delimitado.

## Decisões aplicadas nesta versão

| # | Decisão | Onde mexeu |
|---|---|---|
| D17 | Compatibilidade vira relação N:N entre `Acessorio` e `Produto`, no lugar do campo texto | `aeria-catalogo.puml`, `acessorio-novo.html`, PRD (fecha P1) |
| D18 | `Fornecedor.contato` vira `nomeContato`, `emailContato` e `telefoneContato` | `aeria-catalogo.puml`, `fornecedor-novo.html`, `fornecedores.html`, PRD |

Os 8 diagramas foram validados com `plantuml -checkonly`. O `aeria-catalogo.puml`
renderiza em 3715 px de largura, dentro do limite de 4096 px do PNG.

**CPF/CNPJ no cadastro** segue em `login.html`, na aba Criar conta, e está correto:
o login é por e-mail e senha, e o documento pertence a `PerfilCliente`, coletado no
cadastro ou no checkout. A pendência D1 do PRD foi marcada como aplicada.

## Não entrou nesta revisão

- Telas de moderação de avaliações e perguntas, de chamados e de devoluções. Nenhuma bloqueia os Lotes 1 e 2.
- Os componentes `.dc.html` foram movidos para `legado-componentes/`. A fonte da verdade do protótipo é `site/`, em HTML puro.
- Variações mobile, que seguem adiadas até o desktop estar fechado.
