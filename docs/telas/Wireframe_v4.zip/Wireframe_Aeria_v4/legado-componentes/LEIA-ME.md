# Legado: sistema de componentes `.dc.html`

Estes arquivos são a versão anterior do protótipo, feita com o sistema de
componentes (`dc-import`, `sc-for`, `support.js`). **Não são mais a fonte da
verdade.**

A fonte da verdade do protótipo é a pasta `site/`, em HTML puro.

Ficam aqui por referência histórica. O `AdminNav.dc.html` ainda lista apenas as
6 seções antigas do painel e não reflete as 10 seções atuais. Se um dia você
voltar a usar este sistema, ele precisa ser regerado a partir de `site/`, e não
o contrário.
